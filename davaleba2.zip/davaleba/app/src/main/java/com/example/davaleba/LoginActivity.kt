package com.example.davaleba


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    lateinit var emailTV: TextView
    lateinit var passwordTV: TextView
    lateinit var loginBtn: Button
    lateinit var signUpTV: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val email = intent?.extras?.getString("EMAIL", "DefaultEmail")
        val password = intent?.extras?.getString("PASSWORD", "DefaultPassword")
        val firsName = intent?.extras?.getString("FIRST_NAME", "DefaultName")
        val lastName = intent?.extras?.getString("LAST_NAME", "DefaultLastName")
        val username = intent?.extras?.getString("USERNAME", "DefaultUserName")

        emailTV = findViewById(R.id.editText)
        passwordTV = findViewById(R.id.editText2)
        loginBtn = findViewById(R.id.loginBtn)
        signUpTV = findViewById(R.id.SignUpTV)

        emailTV.text = email

        loginBtn.setOnClickListener {
            if (passwordTV.text.toString() == password){
                val intent = Intent(this, HelloActivity::class.java)
                intent.putExtra("USERNAME", username)
                startActivity(intent)
            }else{
                Toast.makeText(this, "Password Is Incorrect", Toast.LENGTH_SHORT).show()
            }
        }

        signUpTV.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }
}