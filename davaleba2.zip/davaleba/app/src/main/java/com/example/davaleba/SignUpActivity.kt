package com.example.davaleba

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.TextView
import java.net.PasswordAuthentication
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    lateinit var Email: EditText
    lateinit var finishButton: Button
    lateinit var Password: TextView
    lateinit var FirstName: EditText
    lateinit var LastName: EditText
    lateinit var UserName: EditText
    lateinit var registered: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Email = findViewById(R.id.editText2TV)
        Password = findViewById(R.id.passwordTV)
        FirstName = findViewById(R.id.firstnameTV)
        LastName = findViewById(R.id.lastnameTV)
        UserName = findViewById(R.id.editText)
        finishButton = findViewById(R.id.registerTV)
        registered = findViewById(R.id.buttonTV)


        startActivity(intent)
    }

    finishButton.setOnClickListener {
        val FirstName = firsNameTV.text.toString()
        val LastName = lastNameTV.text.toString()
        val Email = editText2TV.text.toString()
        val Password = passwordTV.text.toString()
        val UserName = editText.text.toString()

        val intent = Intent(this, LoginActivity::class.java)
        intent.putExtra("EMAIL", Email)
        intent.putExtra("PASSWORD", Password)
        intent.putExtra("FIRST_NAME", FirstName)
        intent.putExtra("LAST_NAME", LastName)
        intent.putExtra("USERNAME", UserName)

        startActivity(intent)
    }

    alreadyReg.setOnClickListener {
        val intent = Intent(this, LoginActivity::class.java)
        intent.putExtra("EMAIL", "")
        intent.putExtra("PASSWORD", "")
        intent.putExtra("FIRST_NAME", "")
        intent.putExtra("LAST_NAME", "")
        intent.putExtra("USERNAME", "")

        startActivity(intent)
    }
}
