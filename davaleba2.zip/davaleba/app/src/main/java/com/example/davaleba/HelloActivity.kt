package com.example.davaleba

class HelloActivity {
}